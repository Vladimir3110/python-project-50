### Hexlet tests and linter status:
[![Actions Status](https://github.com/Vladimir3110/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Vladimir3110/python-project-50/actions)  [![Maintainability](https://api.codeclimate.com/v1/badges/ec816e4a62081b73ea3b/maintainability)](https://codeclimate.com/github/Vladimir3110/python-project-50/maintainability)
